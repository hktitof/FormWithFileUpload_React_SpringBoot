import React from "react";
import { useState } from 'react';
import axios from "axios";
export default function Candidate() {


    // declaring svariable
const url = "http://localhost:8080/candidate";
const [data,setData] = useState({
  firstname:'',
  lastname:'',
  email:'',
  description:''
});

// handling data for "data var" and showing data input onChange in the console
const handle = (e) =>{
  const {name,value}=e.target;
  const newdata={...data, [name]:value}
  setData(newdata)
  console.log(newdata)
}

// execute this function when clickingon the button submit
function submit(e){
     e.preventDefault();
     //eslint-disable-next-line
     const mailformat = /^([\.\_a-zA-Z0-9]+)@([a-zA-Z]+)\.([a-zA-Z]){2,8}$/;
     //eslint-disable-next-line
      const mailformat2 = /^([\.\_a-zA-Z0-9]+)@([a-zA-Z]+)\.([a-zA-Z]){2,8}\.[a-zA-Z]{1,3}$/;
      var email = document.getElementById("txt_email");
     if(!(email.value.match(mailformat) || email.value.match(mailformat2)) ){
      email.focus();
     }else if(document.getElementById("myFile").value===''){
        alert("Please Upload the file");
     }else{

      

       // for the file
        var formData = new FormData();
        formData.append("filename", document.getElementById("myFile").files[0]);
        formData.append("fname", data.firstname);
        formData.append("lname", data.lastname);
        formData.append("email", data.email);
        formData.append("desc", data.description);
        
       // post formData that contains the file and the dandidate information
      axios.post(url, formData)
      .then(res=>{
        const  received_message =res.data;
        if(received_message==='Candidate Stored'){
         alert("Candidate has been stored");
      
        window.location.reload(false); // Refresh the page
        }else{
          alert("Please try again...");
        }
      })



     }
     
}

    return (
         <div className="container-center">
           
           <div className="container">
             
           <form id="myform"onSubmit={(e) => submit(e)} >

           <center>
              <label className="form_title" htmlFor="Form">Form :</label>
          </center>

          <label htmlFor="fname">First Name</label>
          
          <input  onChange={(e)=>handle(e)} value={data.firstname} type="text" id="fname" name="firstname" placeholder="First name" required minLength="3" maxLength="15"/>
          
          
          


          <label htmlFor="lname">Last Name</label>
          
          <input  onChange={(e)=>handle(e)} value={data.lastname} type="text" id="lname" name="lastname" placeholder="last name" />
          

          <label htmlFor="email">Email</label>
          
          <input  onChange={(e)=>handle(e)} value={data.email} type="text" id="txt_email" name="email" placeholder="Email" required minLength="6"/>
          
          <div className="check_email_valid" id="check_email_valid">Email is Invalide</div>
        

          <label htmlFor="Description">Description</label>
          
          <textarea onChange={(e)=>handle(e)} value={data.description}  className='description' id="Description" name="description" placeholder="txt_Descripton.." required minLength="10"/>
          

          <div className="border_button_choose_file">
            <input value={data.selectedFile} className="button_choose_file" type="file" id="myFile" name="filename" onChange={window['fileValidation']}/>
          </div>


          <input type="submit" value="Submit"/>



           </form>

           </div>
    </div> 
    );
  }
package com.example.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;






@CrossOrigin(origins = "http://localhost:3000")
@Controller
public class Form {
	
	
	
//	private static final Logger logger = LoggerFactory.getLogger(FileController.class);
	private final Logger logger = LoggerFactory.getLogger(Candidate.class);
	ObjectMapper objectMapper = new ObjectMapper();
	Candidate candidate = new Candidate();
	
//	@RequestMapping(value = "/candidate", produces = {"application/json",MediaType.MULTIPART_FORM_DATA_VALUE})
//    @PostMapping("/candidate")
	@PostMapping(value = "/candidate", produces = {"application/json",MediaType.MULTIPART_FORM_DATA_VALUE})
    public ResponseEntity<String> store(@RequestParam("fname") String fname,
    							@RequestParam("lname") String lname,
    							@RequestParam("email") String email,
    							@RequestParam("desc") String desc,
    							@RequestParam("filename") MultipartFile filename ) throws StreamWriteException, DatabindException, IOException {
		candidate.setFirstname(fname);
		candidate.setLastname(lname);
		candidate.setEmail(email);
		candidate.setDescription(desc);
		System.out.println(candidate.toString());
		objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);		
		objectMapper.writeValue(new File("Candidates/"+candidate.getEmail()+".json"), candidate);
		logger.debug("candidate : {}", candidate);
		logger.info(String.format("File name '%s' uploaded successfully.", filename.getOriginalFilename()));
        logger.info(String.format("the file size is : "+filename.getSize()));
		try {
			FileOutputStream outputStream = new FileOutputStream(new File("Candidates/"+candidate.getEmail().concat(".").concat(FilenameUtils.getExtension(filename.getOriginalFilename()))));
			byte[] strToBytes = filename.getBytes();
			outputStream.write(strToBytes);
			outputStream.close();
//            Files.write(fileNamePath, filename.getBytes());
            return new ResponseEntity<>("Candidate Stored", HttpStatus.OK);
        } catch (IOException ex) {
            return new ResponseEntity<>("Image is not uploaded", HttpStatus.BAD_REQUEST);
        }
		
		
		
		
		
		//inside was this and ResponseEntiry has a String object
//    		System.out.println(candidate.toString());
//    		objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);		
//    		objectMapper.writeValue(new File("Candidates/Candidate.json"), candidate);
//    		logger.debug("candidate : {}", candidate);
//    		return new ResponseEntity<>("Candidate Stored", HttpStatus.OK);


    }
}

package com.example.demo;

public class Candidate {
	
	private String firstname;
	private String lastname;
	private String Email;
	private String Description;
	@Override
	public String toString() {
		return "Candidate [lastname=" + lastname + ", firstname=" + firstname + ", email=" + Email + ", description="
				+ Description + "]";
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email = email;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		this.Description = description;
	}
	

}
